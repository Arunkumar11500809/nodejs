const mongoose= require('mongoose');
mongoose.connect('mongobd://localhost:5000/hoteldata',{useNewUrlParser:true,useCreateIndex:true});
var conn=mongoose.Collection;
var userSchema=new mongoose.Schema(
    {
        NumberofGuests:
        {
            type:Int16Array,
            required:true,
            index:
            {
              unique:true,  
            }},
        username:
        {
            type:String,
            required:true,
            index:{
                unique:true,

            }},
            datatime:
        {
            type:datatime,
            required:true,
            index:{
                unique:true,

            }},
            section:
        {
            type:String,
            required:true,
            index:{
                unique:true,

            }},

    }
);
var userModel=mongoose.model('users',userSchema);
module.exports=userModel;