const express = require("express");
const router = express.Router();
const bookingController = require("/booking");

router.get("/", bookingController.fetchAllProducts);

router.get("/booking/productId", bookingController.fetchProductById);
module.exports = router;